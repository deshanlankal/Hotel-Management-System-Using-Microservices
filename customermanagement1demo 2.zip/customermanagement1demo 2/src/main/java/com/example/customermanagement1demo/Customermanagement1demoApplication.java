package com.example.customermanagement1demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Customermanagement1demoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Customermanagement1demoApplication.class, args);
	}

}
