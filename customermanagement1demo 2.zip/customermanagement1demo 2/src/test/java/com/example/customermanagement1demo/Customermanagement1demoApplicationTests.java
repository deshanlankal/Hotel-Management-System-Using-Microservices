package com.example.customermanagement1demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Customermanagement1demoApplicationTests {

	@Test
	void contextLoads() {
	}

}
